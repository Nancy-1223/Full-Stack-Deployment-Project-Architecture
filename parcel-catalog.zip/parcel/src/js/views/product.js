import { h } from "../utils/dom.js";
import { getProduct } from "../api.js";
import { add } from "../store.js";
import { announce } from "../utils/ui.js";
import { money, titleCase } from "../utils/format.js";

export default async function product({ params }) {
  const item = await getProduct(params.id);

  if (!item) {
    return {
      title: "Product not found",
      element: h("div", { class: "page" },
        h("h1", null, "Product not found"),
        h("p", null, "That product does not exist or is no longer sold."),
        h("a", { href: "/products", "data-link": true, class: "btn" }, "Back to the catalog")),
    };
  }

  const addButton = h("button", { type: "button", class: "btn btn--primary" }, "Add to cart");
  addButton.addEventListener("click", () => {
    add(item.id);
    announce(`${item.name} added to cart`);
  });

  return {
    title: item.name,
    element: h("div", { class: "page" },
      h("a", { href: "/products", "data-link": true, class: "back" }, "\u2190 All products"),
      h("div", { class: "detail" },
        h("img", { class: "detail__image", src: `/images/${item.id}.svg`, alt: item.name, width: 600, height: 600, fetchpriority: "high" }),
        h("div", { class: "detail__info" },
          h("p", { class: "card__meta" }, titleCase(item.category)),
          h("h1", null, item.name),
          h("p", { class: "detail__price" }, money(item.price)),
          h("p", null, `Rated ${item.rating.toFixed(1)} out of 5`),
          h("p", { class: "detail__text" }, item.description),
          addButton))),
  };
}
