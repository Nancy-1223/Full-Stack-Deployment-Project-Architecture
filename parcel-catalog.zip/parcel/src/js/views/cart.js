import { h } from "../utils/dom.js";
import { getProducts } from "../api.js";
import { getCart, setQty, remove, clear } from "../store.js";
import { money } from "../utils/format.js";

export default async function cart() {
  const products = await getProducts();
  const root = h("div", { class: "page" });
  let ordered = false;

  function lines() {
    // ignore ids saved earlier for products that no longer exist
    return Object.entries(getCart())
      .map(([id, qty]) => ({ product: products.find((p) => p.id === id), qty }))
      .filter((line) => line.product);
  }

  function paint() {
    const list = lines();
    const total = list.reduce((sum, { product, qty }) => sum + product.price * qty, 0);
    root.replaceChildren(h("h1", null, "Cart"));

    if (ordered) {
      root.append(h("p", { class: "notice" }, "Thanks! This is a demo store, so no payment was taken and nothing will ship."),
        h("a", { href: "/products", "data-link": true, class: "btn" }, "Keep browsing"));
      return;
    }
    if (list.length === 0) {
      root.append(h("p", null, "Your cart is empty."),
        h("a", { href: "/products", "data-link": true, class: "btn btn--primary" }, "Browse the catalog"));
      return;
    }

    root.append(
      h("ul", { class: "lines" }, list.map(({ product, qty }) =>
        h("li", { class: "line" },
          h("img", { src: `/images/${product.id}.svg`, alt: "", width: 80, height: 80, loading: "lazy" }),
          h("div", { class: "line__info" },
            h("a", { href: `/product/${product.id}`, "data-link": true }, product.name),
            h("p", { class: "card__meta" }, money(product.price))),
          h("div", { class: "qty" },
            h("button", { type: "button", class: "btn btn--small", dataset: { act: "dec", id: product.id }, "aria-label": `Decrease quantity of ${product.name}` }, "\u2212"),
            h("span", { "aria-live": "polite" }, qty),
            h("button", { type: "button", class: "btn btn--small", dataset: { act: "inc", id: product.id }, "aria-label": `Increase quantity of ${product.name}` }, "+")),
          h("p", { class: "line__total" }, money(product.price * qty)),
          h("button", { type: "button", class: "btn btn--small btn--quiet", dataset: { act: "remove", id: product.id }, "aria-label": `Remove ${product.name}` }, "Remove")))),
      h("div", { class: "summary" },
        h("p", null, "Subtotal ", h("strong", null, money(total))),
        h("button", { type: "button", class: "btn btn--primary", dataset: { act: "checkout" } }, "Checkout (demo)")));
  }

  // one delegated listener for every button in the cart
  root.addEventListener("click", (event) => {
    const button = event.target.closest("[data-act]");
    if (!button) return;
    const { act, id } = button.dataset;
    const qty = getCart()[id] || 0;
    if (act === "inc") setQty(id, qty + 1);
    else if (act === "dec") setQty(id, qty - 1);
    else if (act === "remove") remove(id);
    else if (act === "checkout") { clear(); ordered = true; }
    paint();
  });

  paint();
  return { title: "Cart", element: root };
}
