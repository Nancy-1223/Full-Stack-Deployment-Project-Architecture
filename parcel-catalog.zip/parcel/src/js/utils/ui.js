/** Announce a message to screen readers through the #live region. */
export function announce(message) {
  const region = document.getElementById("live");
  if (!region) return;
  region.textContent = "";
  // a short delay makes screen readers treat repeated messages as new
  setTimeout(() => { region.textContent = message; }, 50);
}
