import { h } from "../utils/dom.js";
import { getProducts } from "../api.js";
import { productCard, bindAddToCart } from "../components/productCard.js";
import { titleCase } from "../utils/format.js";

const SORTS = {
  featured: { label: "Featured", compare: null },
  "price-asc": { label: "Price: low to high", compare: (a, b) => a.price - b.price },
  "price-desc": { label: "Price: high to low", compare: (a, b) => b.price - a.price },
  rating: { label: "Top rated", compare: (a, b) => b.rating - a.rating },
};

export default async function catalog({ query }) {
  const products = await getProducts();
  const categories = ["all", ...new Set(products.map((p) => p.category))];

  // filter state lives in the URL, so every view is shareable and bookmarkable
  const state = {
    q: query.q || "",
    category: categories.includes(query.category) ? query.category : "all",
    sort: SORTS[query.sort] ? query.sort : "featured",
  };

  const search = h("input", { id: "q", name: "q", type: "search", placeholder: "Search products", value: state.q });
  const category = h("select", { id: "category", name: "category" },
    categories.map((c) => h("option", { value: c, selected: c === state.category }, c === "all" ? "All categories" : titleCase(c))));
  const sort = h("select", { id: "sort", name: "sort" },
    Object.entries(SORTS).map(([value, { label }]) => h("option", { value, selected: value === state.sort }, label)));

  const form = h("form", { class: "filters", role: "search" },
    h("div", { class: "field field--grow" }, h("label", { for: "q" }, "Search"), search),
    h("div", { class: "field" }, h("label", { for: "category" }, "Category"), category),
    h("div", { class: "field" }, h("label", { for: "sort" }, "Sort by"), sort));
  form.addEventListener("submit", (event) => event.preventDefault());

  const status = h("p", { class: "results", "aria-live": "polite" });
  const grid = h("div", { class: "grid" });
  bindAddToCart(grid, products);

  function visible() {
    const needle = state.q.trim().toLowerCase();
    const list = products.filter((p) =>
      (state.category === "all" || p.category === state.category) &&
      (!needle || `${p.name} ${p.description}`.toLowerCase().includes(needle)));
    const { compare } = SORTS[state.sort];
    return compare ? [...list].sort(compare) : list;
  }

  function syncUrl() {
    const params = new URLSearchParams();
    if (state.q) params.set("q", state.q);
    if (state.category !== "all") params.set("category", state.category);
    if (state.sort !== "featured") params.set("sort", state.sort);
    const qs = params.toString();
    history.replaceState({}, "", location.pathname + (qs ? `?${qs}` : ""));
  }

  function paint() {
    const list = visible();
    grid.replaceChildren(...list.map((p) => productCard(p)));
    status.textContent = `${list.length} ${list.length === 1 ? "product" : "products"}`;
    if (list.length === 0) {
      grid.append(h("p", { class: "empty" }, "No products match. Try another search or category."));
    }
    syncUrl();
  }

  form.addEventListener("input", () => {
    state.q = search.value;
    state.category = category.value;
    state.sort = sort.value;
    paint();
  });

  paint();
  return {
    title: "Catalog",
    element: h("div", { class: "page" }, h("h1", null, "Catalog"), form, status, grid),
  };
}
