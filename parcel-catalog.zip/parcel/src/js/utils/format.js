const CURRENCY = "USD"; // change to "INR" etc. in one place
const formatter = new Intl.NumberFormat("en-US", { style: "currency", currency: CURRENCY });

export const money = (amount) => formatter.format(amount);
export const titleCase = (text) => text.charAt(0).toUpperCase() + text.slice(1);
