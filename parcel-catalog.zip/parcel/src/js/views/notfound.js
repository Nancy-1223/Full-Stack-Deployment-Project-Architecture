import { h } from "../utils/dom.js";

export default async function notFound() {
  return {
    title: "Page not found",
    element: h("div", { class: "page" },
      h("h1", null, "Page not found"),
      h("p", null, "The page you asked for does not exist."),
      h("a", { href: "/", "data-link": true, class: "btn" }, "Go home")),
  };
}
