import { h } from "../utils/dom.js";
import { getProducts } from "../api.js";
import { productCard, bindAddToCart } from "../components/productCard.js";
import { titleCase } from "../utils/format.js";

export default async function home() {
  const products = await getProducts();
  const featured = products.filter((p) => p.featured).slice(0, 4);
  const categories = [...new Set(products.map((p) => p.category))];

  const grid = h("div", { class: "grid" }, featured.map(productCard));
  bindAddToCart(grid, products);

  return {
    title: "Everyday objects",
    element: h("div", { class: "page" },
      h("section", { class: "hero" },
        h("h1", null, "Everyday objects, chosen with care."),
        h("p", null, "A small catalog of things we use every day: bags, desk tools, drinkware, audio and watches."),
        h("a", { href: "/products", "data-link": true, class: "btn btn--primary" }, "Browse the catalog")),
      h("section", null,
        h("h2", null, "Featured"),
        grid),
      h("section", null,
        h("h2", null, "Shop by category"),
        h("ul", { class: "chips" }, categories.map((c) =>
          h("li", null, h("a", { href: `/products?category=${c}`, "data-link": true, class: "chip" }, titleCase(c))))))),
  };
}
