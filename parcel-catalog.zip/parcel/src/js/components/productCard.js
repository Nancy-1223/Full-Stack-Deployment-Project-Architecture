import { h } from "../utils/dom.js";
import { money, titleCase } from "../utils/format.js";
import { add } from "../store.js";
import { announce } from "../utils/ui.js";

export function productCard(product) {
  const href = `/product/${product.id}`;
  return h("article", { class: "card" },
    h("a", { href, "data-link": true, class: "card__media", "aria-hidden": "true", tabindex: "-1" },
      h("img", { src: `/images/${product.id}.svg`, alt: "", width: 600, height: 600, loading: "lazy", decoding: "async" })),
    h("div", { class: "card__body" },
      h("h3", { class: "card__title" }, h("a", { href, "data-link": true }, product.name)),
      h("p", { class: "card__meta" }, titleCase(product.category)),
      h("p", { class: "card__price" }, money(product.price))),
    h("button", { type: "button", class: "btn", dataset: { add: product.id } }, "Add to cart"));
}

/** One delegated listener handles every "Add to cart" button inside a container. */
export function bindAddToCart(container, products) {
  container.addEventListener("click", (event) => {
    const button = event.target.closest("[data-add]");
    if (!button) return;
    const product = products.find((p) => p.id === button.dataset.add);
    if (!product) return;
    add(product.id);
    announce(`${product.name} added to cart`);
  });
}
